jQuery(document).ready(function($){
		$(".demo-accordion").accordionjs();
	});